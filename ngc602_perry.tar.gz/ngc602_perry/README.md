Ad hoc code to produce textured 3 dimensional images for a 3-d printer.

General process is to generate an image to be rendered as surface, and then use
a commercial PC program called photo2mesh to turn it into an STL file for a
makerbot replicator 2 printer.

Tailored for NGC 602.
